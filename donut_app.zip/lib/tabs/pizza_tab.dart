import 'package:flutter/material.dart';

class PizzaTab extends StatelessWidget {
  const PizzaTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text('PIZZA TAB'),
      ),
    );
  }
}
