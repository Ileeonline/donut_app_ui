import 'package:flutter/material.dart';

class SmoothieTab extends StatelessWidget {
  const SmoothieTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Text('SMOOTHIE TAB'),
      ),
    );
  }
}
